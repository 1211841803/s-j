import { CalendarPlus, ImagePlus, Images, Settings2, Upload } from "lucide-react";
import { Link } from "react-router-dom";

export function EmptyMemoirBuilder() {
  return (
    <section className="py-6 sm:py-10">
      <div className="mb-6">
        <p className="mb-2 text-base font-bold text-clay">开始搭建</p>
        <h2 className="text-4xl font-semibold leading-tight text-ink">
          先把回忆录框架放好
        </h2>
        <p className="mt-4 text-lg leading-relaxed text-ink/60">
          从封面、年份、照片视频三个位置开始添加自己的内容。
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)]">
        <div className="relative min-h-[22rem] overflow-hidden rounded-lg bg-[linear-gradient(145deg,#2d2924,#667864_56%,#9a5b44)] p-5 text-paper shadow-soft">
          <div className="absolute inset-0 bg-black/16" />
          <div className="relative flex h-full flex-col justify-between">
            <div>
              <p className="text-sm font-bold tracking-[0.2em] text-paper/72">
                COVER
              </p>
              <h3 className="mt-4 text-3xl font-semibold">封面还没有设置</h3>
            </div>
            <Link
              to="/admin"
              className="glass-dark inline-flex min-h-14 items-center justify-center gap-2 rounded-full px-5 text-lg font-bold text-paper"
            >
              <ImagePlus className="h-6 w-6" aria-hidden="true" />
              添加封面
            </Link>
          </div>
        </div>

        <div className="grid gap-4">
          <div className="rounded-lg border border-ink/10 bg-white/72 p-5 shadow-glass">
            <div className="mb-5 flex items-start gap-4">
              <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-clay text-white">
                <CalendarPlus className="h-7 w-7" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-2xl font-semibold">年份时间轴</h3>
                <p className="mt-1 leading-relaxed text-ink/58">
                  先添加年份，例如 1998、2008、2024，再把照片视频放进去。
                </p>
              </div>
            </div>
            <Link
              to="/admin"
              className="inline-flex min-h-[3.25rem] w-full items-center justify-center gap-2 rounded-2xl bg-ink px-5 text-lg font-bold text-paper shadow-soft"
            >
              <CalendarPlus className="h-5 w-5" aria-hidden="true" />
              添加年份
            </Link>
          </div>

          <div className="rounded-lg border border-ink/10 bg-white/72 p-5 shadow-glass">
            <div className="mb-5 flex items-start gap-4">
              <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-sage text-white">
                <Upload className="h-7 w-7" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-2xl font-semibold">照片和视频</h3>
                <p className="mt-1 leading-relaxed text-ink/58">
                  批量选择本地文件，系统会按日期自动分年，也可以指定年份。
                </p>
              </div>
            </div>
            <Link
              to="/admin"
              className="inline-flex min-h-[3.25rem] w-full items-center justify-center gap-2 rounded-2xl bg-sage px-5 text-lg font-bold text-white shadow-soft"
            >
              <Images className="h-5 w-5" aria-hidden="true" />
              添加照片/视频
            </Link>
          </div>
        </div>
      </div>

      <Link
        to="/admin"
        className="mt-4 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-white/76 px-5 font-bold text-ink/70 shadow-glass"
      >
        <Settings2 className="h-5 w-5" aria-hidden="true" />
        打开完整编辑台
      </Link>
    </section>
  );
}
