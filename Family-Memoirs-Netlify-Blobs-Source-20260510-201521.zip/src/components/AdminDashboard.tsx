import {
  closestCenter,
  DndContext,
  type DragEndEvent,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  Download,
  Eye,
  EyeOff,
  FileJson,
  GripVertical,
  ImageIcon,
  Plus,
  RotateCcw,
  Trash2,
  Upload,
  Video,
} from "lucide-react";
import {
  type ChangeEvent,
  type FormEvent,
  useMemo,
  useRef,
  useState,
} from "react";
import { Link } from "react-router-dom";
import { useMemoirs } from "../hooks/useMemoirs";
import { fileToSharedMemoryDraft, readHeroFile } from "../services/cloudMedia";
import type {
  MemoirCollection,
  MemoryDraft,
  MemoryItem,
  MemoryKind,
  YearBlock,
} from "../types/memoir";

function formatDateFromTimestamp(timestamp: number) {
  if (!timestamp) return new Date().toISOString().slice(0, 10);

  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return new Date().toISOString().slice(0, 10);

  return date.toISOString().slice(0, 10);
}

function getYearFromDate(value: string) {
  const year = Number(value.slice(0, 4));
  return Number.isInteger(year) ? year : new Date().getFullYear();
}

function titleFromFileName(name: string) {
  return name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").trim() || "未命名";
}

function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function downloadJson(collection: MemoirCollection) {
  const blob = new Blob([JSON.stringify(collection, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "family-memoirs-data.json";
  link.click();
  URL.revokeObjectURL(url);
}

function isMemoirCollection(value: unknown): value is MemoirCollection {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<MemoirCollection>;
  return (
    typeof candidate.familyName === "string" &&
    typeof candidate.welcomeText === "string" &&
    Array.isArray(candidate.years)
  );
}

export function AdminDashboard() {
  const {
    collection,
    updateCollection,
    replaceCollection,
    addYear,
    updateYear,
    deleteYear,
    toggleYearHidden,
    reorderYears,
    reorderItems,
    addMemory,
    addMemoriesToYear,
    updateMemory,
    moveMemoryToYear,
    deleteMemory,
    resetAllData,
  } = useMemoirs();
  const [newYear, setNewYear] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [uploadYear, setUploadYear] = useState(String(new Date().getFullYear()));
  const [uploadLabel, setUploadLabel] = useState("");
  const [autoGroupByDate, setAutoGroupByDate] = useState(true);
  const [isImporting, setIsImporting] = useState(false);
  const importInputRef = useRef<HTMLInputElement | null>(null);
  const dataInputRef = useRef<HTMLInputElement | null>(null);
  const heroInputRef = useRef<HTMLInputElement | null>(null);
  const newYearInputRef = useRef<HTMLInputElement | null>(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const stats = useMemo(() => {
    const visibleYears = collection.years.filter((year) => !year.hidden).length;
    const memories = collection.years.reduce(
      (count, year) => count + year.items.length,
      0,
    );
    const photos = collection.years.reduce(
      (count, year) =>
        count + year.items.filter((item) => item.kind === "photo").length,
      0,
    );
    const videos = memories - photos;

    return { visibleYears, memories, photos, videos };
  }, [collection.years]);

  const handleAddYear = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const year = Number(newYear);
    if (!Number.isInteger(year) || year < 1900 || year > 2100) return;

    addYear(year, newLabel);
    setNewYear("");
    setNewLabel("");
  };

  const handleHeroUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      updateCollection({ heroImage: await readHeroFile(file) });
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "封面上传失败。");
    }
    event.target.value = "";
  };

  const handleMediaImport = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []).filter((file) =>
      /^(image|video)\//.test(file.type),
    );
    if (files.length === 0) return;

    setIsImporting(true);
    try {
      const grouped = new Map<number, MemoryDraft[]>();
      const fixedYear = Number(uploadYear);

      const drafts = (await Promise.all(files.map(fileToSharedMemoryDraft))).filter(
        (draft): draft is MemoryDraft => draft !== null,
      );

      for (const draft of drafts) {
        const year = autoGroupByDate ? getYearFromDate(draft.date) : fixedYear;
        grouped.set(year, [...(grouped.get(year) ?? []), draft]);
      }

      grouped.forEach((drafts, year) => {
        addMemoriesToYear(
          year,
          autoGroupByDate ? `${year} 年` : uploadLabel,
          drafts,
        );
      });
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "照片/视频上传失败。");
    } finally {
      setIsImporting(false);
      event.target.value = "";
    }
  };

  const handleDataImport = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = JSON.parse(await file.text()) as unknown;
      if (isMemoirCollection(data)) {
        replaceCollection(data);
      } else {
        window.alert("这个 JSON 文件不是家庭回忆录数据。");
      }
    } catch {
      window.alert("JSON 文件读取失败。");
    } finally {
      event.target.value = "";
    }
  };

  const handleDragEnd = ({ active, over }: DragEndEvent) => {
    if (!over || active.id === over.id) return;

    const activeType = active.data.current?.type;
    const overType = over.data.current?.type;

    if (activeType === "year" && overType === "year") {
      reorderYears(String(active.id), String(over.id));
      return;
    }

    if (activeType === "memory" && overType === "memory") {
      const activeYearId = active.data.current?.yearId;
      const overYearId = over.data.current?.yearId;

      if (activeYearId && activeYearId === overYearId) {
        reorderItems(activeYearId, String(active.id), String(over.id));
      }
    }
  };

  return (
    <main className="min-h-screen bg-canvas px-4 py-6 text-ink sm:px-8 lg:px-10">
      <div className="mx-auto max-w-7xl">
        <header className="mb-6 flex flex-col gap-5 border-b border-ink/10 pb-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="mb-2 text-sm font-bold tracking-[0.22em] text-clay">
              EDITOR
            </p>
            <h1 className="text-4xl font-semibold">家庭回忆录编辑台</h1>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link
              to="/"
              className="glass inline-flex min-h-12 items-center rounded-full px-5 font-bold text-ink/72"
            >
              查看前台
            </Link>
            <button
              type="button"
              onClick={() => downloadJson(collection)}
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-sage px-5 font-bold text-white shadow-soft"
            >
              <Download className="h-5 w-5" aria-hidden="true" />
              导出数据
            </button>
            <button
              type="button"
              onClick={() => dataInputRef.current?.click()}
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-ink px-5 font-bold text-paper shadow-soft"
            >
              <FileJson className="h-5 w-5" aria-hidden="true" />
              导入数据
            </button>
            <input
              ref={dataInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={handleDataImport}
            />
          </div>
        </header>

        <section className="mb-6 grid gap-3 rounded-[1.5rem] border border-ink/10 bg-white/74 p-4 shadow-glass sm:grid-cols-2">
          <button
            type="button"
            onClick={() => importInputRef.current?.click()}
            disabled={isImporting}
            className="inline-flex min-h-16 items-center justify-center gap-2 rounded-2xl bg-ink px-5 text-lg font-bold text-paper shadow-soft disabled:opacity-60"
          >
            <Upload className="h-6 w-6" aria-hidden="true" />
            {isImporting ? "正在导入" : "添加照片/视频"}
          </button>
          <button
            type="button"
            onClick={() => {
              setNewYear(String(new Date().getFullYear()));
              newYearInputRef.current?.focus();
            }}
            className="inline-flex min-h-16 items-center justify-center gap-2 rounded-2xl bg-clay px-5 text-lg font-bold text-white shadow-soft"
          >
            <Plus className="h-6 w-6" aria-hidden="true" />
            添加年份
          </button>
        </section>

        <section className="mb-6 grid gap-3 sm:grid-cols-4">
          <Stat label="显示年份" value={stats.visibleYears} />
          <Stat label="媒体总数" value={stats.memories} />
          <Stat label="照片" value={stats.photos} />
          <Stat label="视频" value={stats.videos} />
        </section>

        <section className="mb-6 grid gap-4 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
          <div className="rounded-[1.5rem] border border-ink/10 bg-white/70 p-4 shadow-glass">
            <h2 className="mb-4 text-2xl font-semibold">相册设置</h2>
            <div className="grid gap-3">
              <label className="grid gap-2">
                <span className="text-sm font-bold text-ink/56">相册名称</span>
                <input
                  value={collection.familyName}
                  onChange={(event) =>
                    updateCollection({ familyName: event.target.value })
                  }
                  className="min-h-12 rounded-2xl border border-ink/12 bg-white px-4 text-lg outline-none ring-clay/20 focus:ring-4"
                />
              </label>
              <label className="grid gap-2">
                <span className="text-sm font-bold text-ink/56">欢迎语</span>
                <textarea
                  value={collection.welcomeText}
                  onChange={(event) =>
                    updateCollection({ welcomeText: event.target.value })
                  }
                  rows={3}
                  className="min-h-24 resize-y rounded-2xl border border-ink/12 bg-white px-4 py-3 text-base outline-none ring-clay/20 focus:ring-4"
                />
              </label>
              <div className="grid gap-3 sm:grid-cols-[7rem_minmax(0,1fr)]">
                <button
                  type="button"
                  onClick={() => heroInputRef.current?.click()}
                  className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-clay px-4 font-bold text-white"
                >
                  <ImageIcon className="h-5 w-5" aria-hidden="true" />
                  封面
                </button>
                <input
                  value={collection.heroImage ?? ""}
                  onChange={(event) =>
                    updateCollection({ heroImage: event.target.value })
                  }
                  placeholder="封面图片链接，或点击左侧上传"
                  className="min-h-12 rounded-2xl border border-ink/12 bg-white px-4 outline-none ring-clay/20 focus:ring-4"
                />
                <input
                  ref={heroInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleHeroUpload}
                />
              </div>
            </div>
          </div>

          <div className="rounded-[1.5rem] border border-ink/10 bg-white/70 p-4 shadow-glass">
            <h2 className="mb-4 text-2xl font-semibold">批量导入</h2>
            <div className="grid gap-3">
              <div className="grid gap-3 sm:grid-cols-[9rem_minmax(0,1fr)]">
                <label className="grid gap-2">
                  <span className="text-sm font-bold text-ink/56">指定年份</span>
                  <input
                    value={uploadYear}
                    onChange={(event) => setUploadYear(event.target.value)}
                    type="number"
                    inputMode="numeric"
                    className="min-h-12 rounded-2xl border border-ink/12 bg-white px-4 outline-none ring-clay/20 focus:ring-4"
                  />
                </label>
                <label className="grid gap-2">
                  <span className="text-sm font-bold text-ink/56">年份标题</span>
                  <input
                    value={uploadLabel}
                    onChange={(event) => setUploadLabel(event.target.value)}
                    placeholder="例如：第一次旅行"
                    className="min-h-12 rounded-2xl border border-ink/12 bg-white px-4 outline-none ring-clay/20 focus:ring-4"
                  />
                </label>
              </div>
              <label className="flex min-h-12 items-center gap-3 rounded-2xl bg-canvas px-4 font-semibold text-ink/70">
                <input
                  type="checkbox"
                  checked={autoGroupByDate}
                  onChange={(event) => setAutoGroupByDate(event.target.checked)}
                  className="h-5 w-5 accent-clay"
                />
                按文件日期自动分年
              </label>
              <button
                type="button"
                disabled={isImporting}
                onClick={() => importInputRef.current?.click()}
                className="inline-flex min-h-14 items-center justify-center gap-2 rounded-2xl bg-ink px-5 text-lg font-bold text-paper shadow-soft disabled:opacity-60"
              >
                <Upload className="h-5 w-5" aria-hidden="true" />
                {isImporting ? "正在导入" : "选择照片/视频"}
              </button>
              <input
                ref={importInputRef}
                type="file"
                multiple
                accept="image/*,video/*"
                className="hidden"
                onChange={handleMediaImport}
              />
            </div>
          </div>
        </section>

        <form
          onSubmit={handleAddYear}
          className="mb-6 grid gap-3 rounded-[1.5rem] border border-ink/10 bg-white/58 p-4 sm:grid-cols-[10rem_minmax(0,1fr)_auto]"
        >
          <input
            ref={newYearInputRef}
            value={newYear}
            onChange={(event) => setNewYear(event.target.value)}
            type="number"
            inputMode="numeric"
            aria-label="年份"
            placeholder="年份"
            className="min-h-[3.25rem] rounded-2xl border border-ink/12 bg-white px-4 text-lg outline-none ring-clay/20 transition focus:ring-4"
          />
          <input
            value={newLabel}
            onChange={(event) => setNewLabel(event.target.value)}
            aria-label="年份标题"
            placeholder="手动添加年份标题"
            className="min-h-[3.25rem] rounded-2xl border border-ink/12 bg-white px-4 text-lg outline-none ring-clay/20 transition focus:ring-4"
          />
          <button
            type="submit"
            className="inline-flex min-h-[3.25rem] items-center justify-center gap-2 rounded-2xl bg-clay px-5 font-bold text-white shadow-soft"
          >
            <Plus className="h-5 w-5" aria-hidden="true" />
            添加年份
          </button>
        </form>

        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={collection.years.map((year) => year.id)}
            strategy={verticalListSortingStrategy}
          >
            <div className="grid gap-4">
              {collection.years.map((year) => (
                <SortableYearPanel
                  key={year.id}
                  year={year}
                  years={collection.years}
                  onUpdateYear={(patch) => updateYear(year.id, patch)}
                  onToggleHidden={() => toggleYearHidden(year.id)}
                  onDelete={() => {
                    if (window.confirm(`删除 ${year.year} 年和其中所有内容？`)) {
                      deleteYear(year.id);
                    }
                  }}
                  onAddMemory={(kind) => addMemory(year.id, kind)}
                  onUpdateMemory={(memoryId, patch) =>
                    updateMemory(year.id, memoryId, patch)
                  }
                  onMoveMemory={(memoryId, toYearId) =>
                    moveMemoryToYear(year.id, memoryId, toYearId)
                  }
                  onDeleteMemory={(memoryId) => {
                    if (window.confirm("删除这条媒体？")) {
                      deleteMemory(year.id, memoryId);
                    }
                  }}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>

        {collection.years.length === 0 ? (
          <div className="mt-8 rounded-[1.5rem] border border-dashed border-ink/20 bg-white/54 p-8 text-center">
            <p className="text-2xl font-semibold">还没有内容</p>
            <p className="mt-2 text-ink/56">先批量导入照片或视频，再去前台查看。</p>
          </div>
        ) : null}

        <div className="mt-8 flex justify-end">
          <button
            type="button"
            onClick={() => {
              if (window.confirm("清空全部内容？")) resetAllData();
            }}
            className="inline-flex min-h-12 items-center gap-2 rounded-full bg-ink/8 px-5 font-bold text-clay"
          >
            <RotateCcw className="h-5 w-5" aria-hidden="true" />
            清空内容
          </button>
        </div>
      </div>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass rounded-[1.25rem] p-5">
      <p className="text-sm font-bold text-ink/50">{label}</p>
      <p className="mt-2 text-4xl font-semibold">{value}</p>
    </div>
  );
}

interface SortableYearPanelProps {
  year: YearBlock;
  years: YearBlock[];
  onUpdateYear(patch: Partial<Pick<YearBlock, "year" | "label" | "note" | "hidden">>): void;
  onToggleHidden(): void;
  onDelete(): void;
  onAddMemory(kind: MemoryKind): void;
  onUpdateMemory(memoryId: string, patch: Partial<Omit<MemoryItem, "id" | "yearId">>): void;
  onMoveMemory(memoryId: string, toYearId: string): void;
  onDeleteMemory(memoryId: string): void;
}

function SortableYearPanel({
  year,
  years,
  onUpdateYear,
  onToggleHidden,
  onDelete,
  onAddMemory,
  onUpdateMemory,
  onMoveMemory,
  onDeleteMemory,
}: SortableYearPanelProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: year.id,
    data: { type: "year" },
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <article
      ref={setNodeRef}
      style={style}
      className={`rounded-[1.5rem] border border-ink/10 bg-white/72 p-4 shadow-glass transition ${
        isDragging ? "scale-[0.99] opacity-70" : ""
      }`}
    >
      <div className="grid gap-4 lg:grid-cols-[auto_minmax(0,1fr)_auto]">
        <button
          type="button"
          className="grid min-h-12 min-w-12 place-items-center rounded-2xl bg-ink text-paper"
          aria-label="移动年份"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-6 w-6" aria-hidden="true" />
        </button>

        <div className="grid gap-3">
          <div className="grid gap-3 sm:grid-cols-[9rem_minmax(0,1fr)]">
            <input
              value={year.year}
              type="number"
              inputMode="numeric"
              aria-label={`${year.year} 年份数字`}
              onChange={(event) =>
                onUpdateYear({ year: Number(event.target.value) })
              }
              className="min-h-12 rounded-2xl border border-ink/12 bg-canvas px-4 text-2xl font-semibold outline-none ring-clay/20 focus:ring-4"
            />
            <input
              value={year.label}
              aria-label={`${year.year} 年份标题`}
              onChange={(event) => onUpdateYear({ label: event.target.value })}
              className="min-h-12 rounded-2xl border border-ink/12 bg-canvas px-4 text-lg font-semibold outline-none ring-clay/20 focus:ring-4"
            />
          </div>
          <textarea
            value={year.note}
            aria-label={`${year.year} 年份备注`}
            onChange={(event) => onUpdateYear({ note: event.target.value })}
            rows={2}
            placeholder="这一年的说明"
            className="min-h-20 resize-y rounded-2xl border border-ink/12 bg-canvas px-4 py-3 outline-none ring-clay/20 focus:ring-4"
          />
        </div>

        <div className="flex flex-wrap gap-2 lg:justify-end">
          <button
            type="button"
            onClick={onToggleHidden}
            className="inline-flex min-h-11 items-center gap-2 rounded-full bg-canvas px-4 font-bold text-ink/70"
          >
            {year.hidden ? (
              <Eye className="h-5 w-5" aria-hidden="true" />
            ) : (
              <EyeOff className="h-5 w-5" aria-hidden="true" />
            )}
            {year.hidden ? "显示" : "隐藏"}
          </button>
          <button
            type="button"
            onClick={() => onAddMemory("photo")}
            className="inline-flex min-h-11 items-center gap-2 rounded-full bg-sage px-4 font-bold text-white"
          >
            <ImageIcon className="h-5 w-5" aria-hidden="true" />
            照片
          </button>
          <button
            type="button"
            onClick={() => onAddMemory("video")}
            className="inline-flex min-h-11 items-center gap-2 rounded-full bg-clay px-4 font-bold text-white"
          >
            <Video className="h-5 w-5" aria-hidden="true" />
            视频
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid min-h-11 min-w-11 place-items-center rounded-full bg-clay/10 text-clay"
            aria-label="删除年份"
          >
            <Trash2 className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
      </div>

      <SortableContext
        items={year.items.map((item) => item.id)}
        strategy={verticalListSortingStrategy}
      >
        <div className="mt-5 grid gap-3">
          {year.items.map((memory) => (
            <SortableMemoryRow
              key={memory.id}
              memory={memory}
              yearId={year.id}
              years={years}
              onUpdate={(patch) => onUpdateMemory(memory.id, patch)}
              onMove={(toYearId) => onMoveMemory(memory.id, toYearId)}
              onDelete={() => onDeleteMemory(memory.id)}
            />
          ))}
        </div>
      </SortableContext>
    </article>
  );
}

function SortableMemoryRow({
  memory,
  yearId,
  years,
  onUpdate,
  onMove,
  onDelete,
}: {
  memory: MemoryItem;
  yearId: string;
  years: YearBlock[];
  onUpdate(patch: Partial<Omit<MemoryItem, "id" | "yearId">>): void;
  onMove(toYearId: string): void;
  onDelete(): void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: memory.id,
    data: { type: "memory", yearId },
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };
  const [advancedOpen, setAdvancedOpen] = useState(false);

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`grid gap-3 rounded-[1.25rem] bg-canvas p-3 ${
        isDragging ? "opacity-65" : ""
      }`}
    >
      <div className="grid gap-3 lg:grid-cols-[auto_7rem_minmax(0,1fr)_auto] lg:items-start">
        <button
          type="button"
          className="grid min-h-11 min-w-11 place-items-center rounded-xl bg-white text-ink/48"
          aria-label="移动媒体"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-5 w-5" aria-hidden="true" />
        </button>
        <MediaPreview memory={memory} />
        <div className="grid min-w-0 gap-3">
          <div className="grid gap-3 sm:grid-cols-[7rem_10rem_minmax(0,1fr)]">
            <select
              value={memory.kind}
              aria-label="媒体类型"
              onChange={(event) =>
                onUpdate({ kind: event.target.value as MemoryKind })
              }
              className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 font-semibold outline-none"
            >
              <option value="photo">照片</option>
              <option value="video">视频</option>
            </select>
            <input
              value={memory.date}
              aria-label="拍摄日期"
              type="date"
              onChange={(event) => onUpdate({ date: event.target.value })}
              className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 font-semibold outline-none"
            />
            <input
              value={memory.title}
              aria-label="媒体标题"
              onChange={(event) => onUpdate({ title: event.target.value })}
              placeholder="标题"
              className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 font-semibold outline-none"
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-[12rem_minmax(0,1fr)]">
            <input
              value={memory.place}
              aria-label="地点"
              onChange={(event) => onUpdate({ place: event.target.value })}
              placeholder="地点"
              className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 outline-none"
            />
            <input
              value={memory.caption}
              aria-label="说明文字"
              onChange={(event) => onUpdate({ caption: event.target.value })}
              placeholder="说明文字"
              className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 outline-none"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2 lg:justify-end">
          <select
            value={yearId}
            aria-label="移动到年份"
            onChange={(event) => onMove(event.target.value)}
            className="min-h-11 rounded-full border border-ink/10 bg-white px-3 font-semibold outline-none"
          >
            {years.map((year) => (
              <option key={year.id} value={year.id}>
                {year.year}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => onUpdate({ hidden: !memory.hidden })}
            className="grid min-h-11 min-w-11 place-items-center rounded-full bg-white text-ink/58"
            aria-label={memory.hidden ? "显示媒体" : "隐藏媒体"}
          >
            {memory.hidden ? (
              <Eye className="h-5 w-5" aria-hidden="true" />
            ) : (
              <EyeOff className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setAdvancedOpen((open) => !open)}
            className="min-h-11 rounded-full bg-white px-4 font-bold text-ink/62"
          >
            链接
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid min-h-11 min-w-11 place-items-center rounded-full bg-white text-clay"
            aria-label="删除媒体"
          >
            <Trash2 className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
      </div>

      {advancedOpen ? (
        <div className="grid gap-3 border-t border-ink/10 pt-3 sm:grid-cols-2">
          <input
            value={memory.mediaUrl}
            aria-label="媒体链接"
            onChange={(event) => onUpdate({ mediaUrl: event.target.value })}
            placeholder="图片或视频链接"
            className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 outline-none"
          />
          <input
            value={memory.posterUrl ?? ""}
            aria-label="视频封面链接"
            onChange={(event) => onUpdate({ posterUrl: event.target.value })}
            placeholder="视频封面链接"
            className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 outline-none"
          />
          <input
            value={memory.alt}
            aria-label="替代文字"
            onChange={(event) => onUpdate({ alt: event.target.value })}
            placeholder="替代文字"
            className="min-h-11 rounded-xl border border-ink/10 bg-white px-3 outline-none sm:col-span-2"
          />
        </div>
      ) : null}
    </div>
  );
}

function MediaPreview({ memory }: { memory: MemoryItem }) {
  if (!memory.mediaUrl) {
    return (
      <div className="grid h-24 w-full place-items-center rounded-2xl bg-white text-ink/38 lg:w-28">
        {memory.kind === "photo" ? (
          <ImageIcon className="h-8 w-8" aria-hidden="true" />
        ) : (
          <Video className="h-8 w-8" aria-hidden="true" />
        )}
      </div>
    );
  }

  if (memory.kind === "video") {
    return (
      <video
        src={memory.mediaUrl}
        poster={memory.posterUrl}
        muted
        className="h-24 w-full rounded-2xl object-cover lg:w-28"
      />
    );
  }

  return (
    <img
      src={memory.mediaUrl}
      alt=""
      className="h-24 w-full rounded-2xl object-cover lg:w-28"
    />
  );
}
